import mongoose from 'mongoose';

// 🎨 เก็บสัดส่วน pigment ที่คำนวณจาก LAB
const PigmentSchema = new mongoose.Schema({
  white: { type: Number, default: 0 },
  red: { type: Number, default: 0 },
  yellow: { type: Number, default: 0 },
  black: { type: Number, default: 0 },
  brown: { type: Number, default: 0 },
}, { _id: false });

// 💾 ข้อมูลการสแกนจาก ESP32 / Mock
const ScanSchema = new mongoose.Schema({
  user_id: { type: String, required: true },

  // 📊 ค่าที่คำนวณได้จาก raw sensor
  L: { type: Number, required: true },
  a: { type: Number, required: true },
  b: { type: Number, required: true },
  deltaE: { type: Number, required: true },

  // 💡 วิเคราะห์ undertone + shade
  undertone: { type: String, enum: ['Warm', 'Cool', 'Neutral'], default: 'Neutral' },
  shade: { type: String, default: 'Unknown' },
  shade_code: { type: String, default: '' },

  // ⚙️ สูตรผสม pigment หลังคำนวณ
  pigment: { type: PigmentSchema, default: undefined },

  // 🧭 ค่าดิบจาก sensor (f1–f8, clear, nir)
  raw: {
    f1: Number, f2: Number, f3: Number, f4: Number,
    f5: Number, f6: Number, f7: Number, f8: Number,
    clear: Number, nir: Number
  },

  // ⏱️ สถานะการทำงาน เช่น "Scanned", "Mixed"
  status: { type: String, default: 'Scanned' }

}, { timestamps: true });

export const Scan = mongoose.model('Scan', ScanSchema);
