import mongoose from 'mongoose';

const MixHistorySchema = new mongoose.Schema({
  user_id: { type: String, required: true },
  scan_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Scan' },
  formula: {
    white: { type: Number, required: true },
    red: { type: Number, required: true },
    yellow: { type: Number, required: true },
    black: { type: Number, required: true },
    brown: { type: Number, required: true },
  },
  status: { type: String, enum: ['Pending', 'Sent', 'Completed', 'Failed', 'Saved'], default: 'Pending' }
}, { timestamps: true });

export const MixHistory = mongoose.model('MixHistory', MixHistorySchema);
