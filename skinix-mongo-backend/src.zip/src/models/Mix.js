import mongoose from 'mongoose';

const mixSchema = new mongoose.Schema({
  user_id: String,
  scan_id: { type: mongoose.Schema.Types.ObjectId, ref: 'Scan' },
  formula: Object,
  shade: String,
  shade_code: String,
  undertone: String,
  L: Number,
  a: Number,
  b: Number,
  status: { type: String, default: 'Pending' },
}, { timestamps: true });

export const Mix = mongoose.model('Mix', mixSchema);
