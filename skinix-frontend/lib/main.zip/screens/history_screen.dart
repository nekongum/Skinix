import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';
import '../theme/app_colors.dart';
import '../services/api_service.dart';

class HistoryScreen extends StatefulWidget {
  const HistoryScreen({super.key});

  @override
  State<HistoryScreen> createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<dynamic> _history = [];
  List<dynamic> _filteredHistory = [];
  bool _loading = true;
  final TextEditingController _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  /// 📡 ดึงข้อมูลประวัติการผสมจาก Backend
  Future<void> _loadHistory() async {
    try {
      final data = await ApiService().getMixHistory('saruta_01');
      setState(() {
        _history = data;
        _filteredHistory = data;
        _loading = false;
      });
    } catch (e) {
      print('❌ Error loading history: $e');
      setState(() => _loading = false);
    }
  }

  /// 🔍 ฟิลเตอร์ผลลัพธ์ตามคำค้นหา
  void _filterHistory(String query) {
    final filtered = _history.where((item) {
      final name = (item['user_name'] ?? '').toString().toLowerCase();
      final shade = (item['shade'] ?? '').toString().toLowerCase();
      final undertone = (item['undertone'] ?? '').toString().toLowerCase();
      return name.contains(query.toLowerCase()) ||
          shade.contains(query.toLowerCase()) ||
          undertone.contains(query.toLowerCase());
    }).toList();

    setState(() => _filteredHistory = filtered);
  }

  /// 🎨 LAB → สี RGB (ประมาณ)
  Color _labToColor(double L, double a, double b) {
    final r = (L + a * 1.1).clamp(0, 100);
    final g = (L - 0.3 * a - 0.6 * b).clamp(0, 100);
    final bl = (L + b * 1.2).clamp(0, 100);
    return Color.fromARGB(
      255,
      (r / 100 * 255).toInt(),
      (g / 100 * 255).toInt(),
      (bl / 100 * 255).toInt(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: const BottomNavBar(currentIndex: 0),
      body: SafeArea(
        child: _loading
            ? const Center(
                child: CircularProgressIndicator(color: AppColors.primaryBrown))
            : Column(
                children: [
                  // 🔶 Header
                  Container(
                    width: double.infinity,
                    color: AppColors.primaryBrown,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    child: const Center(
                      child: Text(
                        "Color History",
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),

                  const SizedBox(height: 12),

                  // 🔶 Search bar
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Row(
                      children: [
                        Expanded(
                          child: Container(
                            decoration: BoxDecoration(
                              color: Colors.white,
                              borderRadius: BorderRadius.circular(8),
                              border: Border.all(
                                  color: AppColors.primaryBrown, width: 1),
                            ),
                            child: Row(
                              children: [
                                const SizedBox(width: 8),
                                const Icon(Icons.search,
                                    color: AppColors.primaryBrown),
                                const SizedBox(width: 6),
                                Expanded(
                                  child: TextField(
                                    controller: _searchCtrl,
                                    onChanged: _filterHistory,
                                    decoration: const InputDecoration(
                                      hintText: "Search",
                                      border: InputBorder.none,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Container(
                          decoration: BoxDecoration(
                            color: AppColors.primaryBrown,
                            borderRadius: BorderRadius.circular(8),
                          ),
                          child: IconButton(
                            icon: const Icon(Icons.calendar_today,
                                color: Colors.white),
                            onPressed: () {
                              // 📅 TODO: filter by date later
                            },
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  // 🔶 History list (real data)
                  Expanded(
                    child: _filteredHistory.isEmpty
                        ? const Center(
                            child: Text("No mix history found",
                                style: TextStyle(color: Colors.grey)),
                          )
                        : ListView.builder(
                            padding:
                                const EdgeInsets.symmetric(horizontal: 16),
                            itemCount: _filteredHistory.length,
                            itemBuilder: (context, index) {
                              final item = _filteredHistory[index];
                              final color = _labToColor(
                                (item['L'] ?? 70).toDouble(),
                                (item['a'] ?? 0).toDouble(),
                                (item['b'] ?? 0).toDouble(),
                              );

                              final createdAt = DateTime.tryParse(
                                      item['createdAt'] ?? '') ??
                                  DateTime.now();
                              final dateStr =
                                  "${createdAt.year}-${createdAt.month.toString().padLeft(2, '0')}-${createdAt.day.toString().padLeft(2, '0')} ${createdAt.hour.toString().padLeft(2, '0')}:${createdAt.minute.toString().padLeft(2, '0')}";

                              return ColorHistoryCard(
                                name: item['user_name'] ?? 'Unknown',
                                tone: item['shade'] ?? 'N/A',
                                hex: item['shade_code'] ?? '',
                                lab:
                                    "(${item['L']}, ${item['a']}, ${item['b']})",
                                date: dateStr,
                                colorSample: color,
                              );
                            },
                          ),
                  ),
                ],
              ),
      ),
    );
  }
}

/// 🔹 Widget แสดงแต่ละประวัติ
class ColorHistoryCard extends StatelessWidget {
  final String name;
  final String tone;
  final String hex;
  final String lab;
  final String date;
  final Color colorSample;

  const ColorHistoryCard({
    super.key,
    required this.name,
    required this.tone,
    required this.hex,
    required this.lab,
    required this.date,
    required this.colorSample,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 4,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // 🔸 Sample Color
          Container(
            width: 60,
            height: 60,
            decoration: BoxDecoration(
              color: colorSample,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: Colors.grey.shade300),
            ),
          ),
          const SizedBox(width: 12),

          // 🔸 Text Info
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  name,
                  style: const TextStyle(
                    color: AppColors.textDark,
                    fontWeight: FontWeight.w700,
                    fontSize: 15,
                  ),
                ),
                Text(tone,
                    style: const TextStyle(
                      color: AppColors.textDark,
                      fontWeight: FontWeight.w500,
                    )),
                const SizedBox(height: 4),
                Text("HEX: $hex", style: _infoStyle()),
                Text("LAB: $lab", style: _infoStyle()),
                const SizedBox(height: 4),
                Text(
                  date,
                  style: const TextStyle(fontSize: 11, color: Colors.grey),
                ),
              ],
            ),
          ),

          // 🔸 Mix again
          Align(
            alignment: Alignment.bottomRight,
            child: TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/mixing');
              },
              child: const Text(
                "Mix Again",
                style: TextStyle(
                    color: AppColors.primaryBrown,
                    fontWeight: FontWeight.w600,
                    fontSize: 13),
              ),
            ),
          ),
        ],
      ),
    );
  }

  static TextStyle _infoStyle() => const TextStyle(
        color: AppColors.textDark,
        fontSize: 13,
      );
}
