import 'package:flutter/material.dart';
import '../widgets/bottom_nav.dart';
import '../theme/app_colors.dart';
import '../services/api_service.dart'; // ✅ เพิ่ม import เชื่อม backend

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  // 🔹 ฟังก์ชัน Logout Popup
  Future<void> _confirmLogout(BuildContext context) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Logout"),
        content: const Text("Are you sure you want to log out?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primaryBrown,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Logout", style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );

    if (confirm == true) {
      if (!context.mounted) return;
      Navigator.pushNamedAndRemoveUntil(context, '/login', (route) => false);
    }
  }

  // 🔹 ฟังก์ชันเริ่มสแกน (เชื่อมกับ Backend)
  Future<void> _startScan(BuildContext context) async {
    final api = ApiService();
    try {
      // แสดง Loading Popup
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (_) => const Center(
          child: CircularProgressIndicator(color: AppColors.primaryBrown),
        ),
      );

      // 🔸 เรียก API เพื่อสั่งให้ ESP32 เริ่มสแกน
      await api.startScan();

      // ปิด Loading
      if (context.mounted) Navigator.pop(context);

      // 🔸 ไปหน้า Scanning หลังสั่งสำเร็จ
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Scanning started...'),
            backgroundColor: AppColors.primaryBrown,
          ),
        );
        Navigator.pushNamed(context, '/scanning');
      }
    } catch (e) {
      // ปิด Loading ถ้ามี error
      if (context.mounted) Navigator.pop(context);

      // แสดง error
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Failed to start scan: $e'),
          backgroundColor: Colors.red.shade400,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: const BottomNavBar(currentIndex: 1),
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // 🔶 Header
              Container(
                color: AppColors.primaryBrown,
                padding: const EdgeInsets.all(16),
                width: double.infinity,
                child: Row(
                  children: [
                    const CircleAvatar(
                      radius: 30,
                      backgroundImage: AssetImage('assets/images/profile.jpg'),
                    ),
                    const SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: const [
                        Text(
                          "Hi Pimmy,",
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: 20,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text(
                          "Perfect tone, Perfect you",
                          style: TextStyle(color: Colors.white70),
                        ),
                      ],
                    ),
                    const Spacer(),
                    IconButton(
                      tooltip: "Logout",
                      icon: const Icon(Icons.logout, color: Colors.white),
                      onPressed: () => _confirmLogout(context),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),

              // 🔶 Quick Tips title
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: Text(
                  "Quick Tips",
                  style: TextStyle(
                    color: AppColors.textDark,
                    fontSize: 20,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),

              const SizedBox(height: 10),

              // 🔶 Tip Cards
              SizedBox(
                height: 200,
                child: ListView(
                  scrollDirection: Axis.horizontal,
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  children: const [
                    TipCard(
                      icon: Icons.wb_sunny_rounded,
                      text: "Scan in a well-lit area for more accurate results.",
                    ),
                    SizedBox(width: 16),
                    TipCard(
                      icon: Icons.water_drop_outlined,
                      text: "Clean your skin before scanning for better results.",
                    ),
                    SizedBox(width: 16),
                    TipCard(
                      icon: Icons.spa_rounded,
                      text: "Avoid heavy makeup before scanning for best tone match.",
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 30),

              // 🔶 Scan section
              Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.85,
                  padding: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: AppColors.lightBrown.withOpacity(0.3),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Column(
                    children: [
                      const Text(
                        "Tap to scan your skin\nAnd get your perfect foundation",
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: AppColors.textDark,
                          fontSize: 16,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      const SizedBox(height: 20),
                      // ✅ ปุ่ม Scan Skin (เวอร์ชันใหม่ที่เชื่อม API)
                      ElevatedButton(
                        onPressed: () => _startScan(context),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primaryBrown,
                          padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 12),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        child: const Text(
                          "Scan Skin",
                          style: TextStyle(color: Colors.white, fontSize: 16),
                        ),
                      ),
                      const SizedBox(height: 10),
                      OutlinedButton(
                        onPressed: () {},
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: AppColors.primaryBrown),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                        ),
                        child: const Text(
                          "How To Scan",
                          style: TextStyle(color: AppColors.primaryBrown),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              const SizedBox(height: 40),
            ],
          ),
        ),
      ),
    );
  }
}

// 🔹 TipCard Widget (ใหญ่ขึ้น)
class TipCard extends StatelessWidget {
  final IconData icon;
  final String text;

  const TipCard({super.key, required this.icon, required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: 160,
      height: 180,
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: AppColors.cream,
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: AppColors.primaryBrown, size: 54),
          const SizedBox(height: 14),
          Text(
            text,
            style: const TextStyle(
              color: AppColors.textDark,
              fontSize: 14,
              height: 1.3,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
