import 'package:flutter/material.dart';
import 'screens/home_screen.dart';
import 'screens/scanning_screen.dart';
import 'screens/result_screen.dart';
import 'screens/mixing_screen.dart';
import 'screens/ready_screen.dart';
import 'screens/history_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/welcome_screen.dart';
import 'screens/login_screen.dart';
import 'screens/signup_screen.dart';
import 'services/api_service.dart' show ApiService;
import 'theme/app_colors.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final api = ApiService();
  await api.testConnection(); // ✅ ตรวจ backend ก่อน
  runApp(const SmartFoundationApp());
}

class SmartFoundationApp extends StatelessWidget {
  const SmartFoundationApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Foundation Mixer',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        scaffoldBackgroundColor: Colors.white,
        fontFamily: 'Poppins',
        colorScheme: ColorScheme.fromSeed(seedColor: AppColors.primaryBrown),
        useMaterial3: true,
      ),
      routes: {
        '/': (context) => const WelcomeScreen(),
        '/login': (context) => const LoginScreen(),
        '/signup': (context) => const SignUpScreen(),
        '/home': (context) => const HomeScreen(),
        '/scanning': (context) => const ScanningScreen(),
        '/result': (context) => const ResultScreen(),
        '/mixing': (context) => const MixingScreen(),
        '/ready': (context) => const ReadyScreen(),
        '/history': (context) => const HistoryScreen(),
        '/profile': (context) => const ProfileScreen(),
      },
      initialRoute: '/',
    );
  }
}
